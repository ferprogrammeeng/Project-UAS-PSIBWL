from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re


app = Flask(__name__)
app.secret_key = 'abcde_fghaijlmotwruta'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'pythonlogin'

mysql = MySQL(app)


@app.route('/login/', methods=['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        # Buat variable untuk akses yang mudah
        username = request.form['username']
        password = request.form['password']

        # periksa if account ada menggunakan perintah SQL
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts \
            WHERE username = %s AND password = %s',
            (username, password))

        # ambil satu record dan return hasilnya
        account = cursor.fetchone()
        cursor.close()

        # jika akun ada dalam table accounts di database
        if account:
            # Buat session data, kita bisa mengkases data ini
            # dalam route lain
            session['loggedin'] = True
            session['id'] = account['id']
            session['username'] = account['username']

            # Redirect ke halaman home
            return redirect(url_for('home'))
        else:
            msg = 'Incorrect username/password!'

    return render_template('login.html', msg='')


@app.route('/login/logout')
def logout():
   # Hapus data sesi, ini akan membuat user logout
   session.pop('loggedin', None)
   session.pop('id', None)
   session.pop('username', None)
   # Kembalikan ke halaman login
   return redirect(url_for('login'))


@app.route('/login/register', methods=['GET', 'POST'])
def register():
    # peasn output jika terjadi kesalahan...
    msg = ''
    # Periksan jika "username", "password" dan "email" POST
    # requests ada (user submitted form)
    if request.method == 'POST' and 'username' in request.form \
        and 'password' in request.form and 'email' in request.form:
        # Buat variable untuk akses mudah
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts \
            WHERE username = %s', (username,))
        account = cursor.fetchone()
        cursor.close()


        # Jika akun ada tampilkan error dan lakukan validasi
        if account:
            msg = 'Akun sudah ada!'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Email address invalid!'
        elif not re.match(r'[A-Za-z0-9]+', username):
            msg = 'Username harus membuat karakter dan angka!'
        elif not username or not password or not email:
            msg = 'Isi semua form!'
        else:
            # Akun tidak ada dan form data valid, sekarang
            # insert akun baru ke table accounts
            cursor.execute('INSERT INTO accounts VALUES (NULL,\
                %s, %s, %s)', (username, password, email,))
            mysql.connection.commit()
            msg = 'Anda sukses mendaftar!'


    elif request.method == 'POST':
        # form kosong... (no POST data)
        msg = 'isi semua form!'

    # Tampilkan dorm registrasi dengan pesan
    return render_template('register.html', msg=msg)


@app.route('/login/home')
def home():
    # Periksa jika user loggedin
    if 'loggedin' in session:
        # User loggedin tampilkan halaman home
        return render_template('home.html', username=session["username"])
    # User tidak loggedin kembalikan ke halaman login
    return redirect(url_for('login'))


@app.route('/login/profile')
def profile():
    # Periksa jika user loggedin
    if 'loggedin' in session:
        # Kita memerlukan semua info akun bagi user yang login dan
        # menampilkannya pada halaman profile
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts \
            WHERE id = %s', (session['id'],))
        account = cursor.fetchone()
        cursor.close()

        # Tampilkan informasi akun pada halaman profile
        return render_template('profile.html', account=account)

    # User yang tidak loggedin diarahkan Kembali ke halaman login
    return redirect(url_for('login'))


@app.route('/dosen')
def dosen():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM dosen')
    dosen = cursor.fetchall()
    cursor.close()

    return render_template('dosen.html', data=dosen)


@app.route('/dosen/add', methods=["GET","POST"])
def dosen_add():
    print(request.method)
    if request.method == "GET":
        return render_template('dosen_add.html', )
    elif request.method == "POST":
        nama = request.form["nama"]
        jurusan = request.form["jurusan"]

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("""INSERT INTO dosen VALUES(
            "", %s, %s
        )""", [nama, jurusan])
        mysql.connection.commit()
        cursor.close()

        return redirect(url_for('dosen'))
    

@app.route('/dosen/edit', methods=["POST"])
@app.route('/dosen/edit/<id>', methods=["GET"])
def dosen_edit(id=None):
    cursor = mysql.connection.cursor()
    if request.method == "GET":
        cursor.execute('SELECT * FROM dosen WHERE id = %s', (id,))
        dosen = cursor.fetchone()
        cursor.close()

        return render_template('dosen_edit.html', data=dosen)
    else:
        id = request.form["id"]
        nama = request.form["nama"]
        jurusan = request.form["jurusan"]

        cursor.execute("""UPDATE dosen SET
            nama = %s,
            jurusan = %s
        WHERE id = %s""", [nama, jurusan, id] )

        mysql.connection.commit()
        cursor.close()

        return redirect(url_for('dosen'))


@app.route('/dosen/delete/<id>', methods=["GET"])
def dosen_delete(id):
    cursor = mysql.connection.cursor()
    cursor.execute("DELETE FROM dosen WHERE id = %s", (id,))
    mysql.connection.commit()
    cursor.close()

    return redirect(url_for('dosen'))


if __name__ == "__main__":
    app.run(debug=True, port=3000)
